package com.gamingroom;

/**
 * A class to test a singleton's behavior
 * 
 * This class ensures that only one instance of GameService is created and used.
 * 
 * The singleton pattern is used to restrict the instantiation of a class to one single instance.
 * In this case, we need only one instance of GameService to manage the games.
 * 
 * By implementing the singleton pattern, we ensure that there is only one instance of GameService,
 * which can be accessed globally, providing a single point of access to the list of games.
 * 
 * @autor coce@snhu.edu
 */
public class SingletonTester {

    public void testSingleton() {
        
        System.out.println("\nAbout to test the singleton...");
        
        // Obtain local reference to the singleton instance
        GameService service = GameService.getInstance();
        
        // A simple for loop to print the games
        for (int i = 0; i < service.getGameCount(); i++) {
            System.out.println(service.getGame(i));
        }
    }
}
