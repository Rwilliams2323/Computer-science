package com.gamingroom;

/**
 * Application start-up program
 * 
 * The ProgramDriver class demonstrates the use of the singleton pattern 
 * by obtaining the single instance of the GameService and using it to 
 * add and retrieve game instances.
 * 
 * This example also demonstrates that only one instance of the GameService 
 * exists by using a separate tester class.
 * 
 * @author coce@snhu.edu
 */
public class ProgramDriver {
	
	/**
	 * The one-and-only main() method
	 * 
	 * @param args command line arguments
	 */
	public static void main(String[] args) {
		
		// Obtain reference to the singleton instance of GameService
		GameService service = GameService.getInstance();
		
		System.out.println("\nAbout to test initializing game data...");
		
		// Initialize with some game data
		Game game1 = service.addGame("Game #1");
		System.out.println(game1);
		Game game2 = service.addGame("Game #2");
		System.out.println(game2);
		
		// Use another class to prove there is only one instance
		SingletonTester tester = new SingletonTester();
		tester.testSingleton();
	}
}

package com.gamingroom;

/**
 * A simple tester class to test the singleton instance of GameService
 * 
 * This class ensures that only one instance of GameService is created and used.
 * 
 * @autor coce@snhu.edu
 */
public class SingletonTester {
    
    public void testSingleton() {
        // Obtain reference to the singleton instance of GameService
        GameService service1 = GameService.getInstance();
        GameService service2 = GameService.getInstance();
        
        // Check if both references point to the same instance
        if (service1 == service2) {
            System.out.println("Both references point to the same instance.");
        } else {
            System.out.println("The references point to different instances.");
        }
    }
}
