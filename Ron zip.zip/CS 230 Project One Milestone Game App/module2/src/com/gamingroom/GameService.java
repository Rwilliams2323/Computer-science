package com.gamingroom;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * A singleton service for the game engine
 * 
 * The singleton pattern is used to restrict the instantiation of a class to one single instance.
 * This is useful when exactly one object is needed to coordinate actions across the system.
 * In this case, we need only one instance of GameService to manage the games.
 * 
 * The characteristics of the singleton pattern include:
 * - A private static variable to hold the single instance of the class.
 * - A private constructor to prevent instantiation from other classes.
 * - A public static method that returns the single instance of the class, creating it if it doesn't already exist.
 * - Thread-safety to ensure that the singleton instance is created safely in a multi-threaded environment.
 * 
 * By implementing the singleton pattern, we ensure that there is only one instance of GameService,
 * which can be accessed globally, providing a single point of access to the list of games.
 * 
 * The iterator pattern is used to access the elements of a collection sequentially without exposing its underlying representation.
 * In this context, the iterator pattern is useful to traverse the list of games to find a game by its name or ID.
 * 
 * The characteristics of the iterator pattern include:
 * - Providing a way to access elements of a collection sequentially without exposing the underlying structure.
 * - Supporting multiple traversal algorithms and allowing iteration over different collections in a uniform manner.
 * - Simplifying the code needed to traverse a collection by abstracting the traversal process.
 * 
 * The factory method pattern is used to create objects without specifying the exact class of object that will be created.
 * This pattern provides an interface for creating objects in a superclass but allows subclasses to alter the type of objects that will be created.
 * In this context, the factory method pattern is used to create game instances.
 * 
 * @author coce@snhu.edu
 */
public class GameService {

    // A list of the active games
    private static List<Game> games = new ArrayList<>();

    // Holds the next game identifier
    private static long nextGameId = 1;

    // The single instance of the GameService class
    private static volatile GameService instance;

    // Private constructor to prevent instantiation
    private GameService() { }

    // Public method to provide access to the single instance of the class
    public static GameService getInstance() {
        if (instance == null) {
            synchronized (GameService.class) {
                if (instance == null) {
                    instance = new GameService();
                }
            }
        }
        return instance;
    }

    /**
     * Factory method to create a new game instance.
     * 
     * @param name the unique name of the game
     * @return the new game instance
     */
    private Game createGame(String name) {
        return new Game(nextGameId++, name);
    }

    /**
     * Construct a new game instance
     * 
     * @param name the unique name of the game
     * @return the game instance (new or existing)
     */
    public Game addGame(String name) {

        // A local game instance
        Game game = null;

        // Use iterator to look for existing game with same name
        Iterator<Game> iterator = games.iterator();
        while (iterator.hasNext()) {
            Game existingGame = iterator.next();
            if (existingGame.getName().equalsIgnoreCase(name)) {
                game = existingGame;
                break;
            }
        }

        // If not found, make a new game instance and add to list of games
        if (game == null) {
            game = createGame(name);
            games.add(game);
        }

        // Return the new/existing game instance to the caller
        return game;
    }

    /**
     * Returns the game instance at the specified index.
     * <p>
     * Scope is package/local for testing purposes.
     * </p>
     * @param index index position in the list to return
     * @return requested game instance
     */
    Game getGame(int index) {
        return games.get(index);
    }

    /**
     * Returns the game instance with the specified id.
     * 
     * @param id unique identifier of game to search for
     * @return requested game instance
     */
    public Game getGame(long id) {

        // A local game instance
        Game game = null;

        // Use iterator to look for existing game with same id
        Iterator<Game> iterator = games.iterator();
        while (iterator.hasNext()) {
            Game existingGame = iterator.next();
            if (existingGame.getId() == id) {
                game = existingGame;
                break;
            }
        }

        return game;
    }

    /**
     * Returns the game instance with the specified name.
     * 
     * @param name unique name of game to search for
     * @return requested game instance
     */
    public Game getGame(String name) {

        // A local game instance
        Game game = null;

        // Use iterator to look for existing game with same name
        Iterator<Game> iterator = games.iterator();
        while (iterator.hasNext()) {
            Game existingGame = iterator.next();
            if (existingGame.getName().equalsIgnoreCase(name)) {
                game = existingGame;
                break;
            }
        }

        return game;
    }

    /**
     * Returns the number of games currently active
     * 
     * @return the number of games currently active
     */
    public int getGameCount() {
        return games.size();
    }
}
